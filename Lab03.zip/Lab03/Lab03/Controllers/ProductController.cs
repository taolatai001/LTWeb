﻿using Lab03.Models;
using Lab03.Repository;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Threading.Tasks;
using System.IO;

namespace Lab03.Controllers
{
    public class ProductController : Controller
    {
        private readonly IProductRepository _productRepository;
        private readonly ICategoryRepository _categoryRepository;

        public ProductController(IProductRepository productRepository, ICategoryRepository categoryRepository)
        {
            _productRepository = productRepository;
            _categoryRepository = categoryRepository;
        }

        public async Task<IActionResult> Index()
        {
            var products = await _productRepository.GetAllAsync();
            var categories = await _categoryRepository.GetAllAsync();

            foreach (var product in products)
            {
                var category = categories.FirstOrDefault(c => c.Id == product.CategoryId);
                product.CategoryName = category?.Name_ ?? "Không có";
            }

            return View(products);
        }

        public async Task<IActionResult> Add()
        {
            ViewBag.Categories = new SelectList(await _categoryRepository.GetAllAsync(), "Id", "Name_");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Add(Product product, IFormFile? imageFile, string? imageUrl)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Categories = new SelectList(await _categoryRepository.GetAllAsync(), "Id", "Name_");
                return View(product);
            }

            product.ImageUrl = await HandleImageUpload(imageFile, imageUrl);
            await _productRepository.AddAsync(product);
            TempData["SuccessMessage"] = "Thêm sản phẩm thành công!";
            return RedirectToAction(nameof(Index));
        }
        public async Task<IActionResult> Details(int id)
        {
            if (id <= 0)
            {
                TempData["ErrorMessage"] = "ID sản phẩm không hợp lệ!";
                return RedirectToAction(nameof(Index));
            }

            var product = await _productRepository.GetByIdAsync(id);

            if (product == null)
            {
                TempData["ErrorMessage"] = "Sản phẩm không tồn tại!";
                return RedirectToAction(nameof(Index));
            }

            // Kiểm tra xem CategoryId có giá trị không trước khi gọi GetByIdAsync
            if (product.CategoryId.HasValue)
            {
                product.Category = await _categoryRepository.GetByIdAsync(product.CategoryId.Value);
            }

            return View(product);
        }




        public async Task<IActionResult> Update(int id)
        {
            var product = await _productRepository.GetByIdAsync(id);
            if (product == null) return NotFound();

            ViewBag.Categories = new SelectList(await _categoryRepository.GetAllAsync(), "Id", "Name_", product.CategoryId);
            return View(product);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Update(int id, Product product, IFormFile? imageFile, string? imageUrl)
        {
            if (id != product.Id) return NotFound();

            var existingProduct = await _productRepository.GetByIdAsync(id);
            if (existingProduct == null) return NotFound();

            existingProduct.Name_ = product.Name_;
            existingProduct.Price = product.Price;
            existingProduct.Description_ = product.Description_;
            existingProduct.CategoryId = product.CategoryId;

            // Gọi HandleImageUpload để giữ ảnh cũ nếu không có ảnh mới
            existingProduct.ImageUrl = await HandleImageUpload(imageFile, imageUrl, existingProduct.ImageUrl);

            await _productRepository.UpdateAsync(existingProduct);
            TempData["SuccessMessage"] = "Cập nhật sản phẩm thành công!";
            return RedirectToAction(nameof(Index));
        }
        public async Task<IActionResult> Delete(int id)
        {
            var product = await _productRepository.GetByIdAsync(id);
            if (product == null)
            {
                TempData["ErrorMessage"] = "Sản phẩm không tồn tại!";
                return RedirectToAction(nameof(Index));
            }

            return View(product);
        }

        [HttpPost, ActionName("DeleteConfirmed")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var product = await _productRepository.GetByIdAsync(id);
            if (product == null)
            {
                TempData["ErrorMessage"] = "Sản phẩm không tồn tại!";
                return RedirectToAction(nameof(Index));
            }

            await _productRepository.DeleteAsync(id);
            TempData["SuccessMessage"] = "Xóa sản phẩm thành công!";
            return RedirectToAction(nameof(Index));
        }

        private async Task<string?> HandleImageUpload(IFormFile? imageFile, string? imageUrl, string? existingImageUrl = null)
        {
            if (imageFile != null && imageFile.Length > 0)
            {
                // Tạo tên file duy nhất
                string uniqueFileName = $"{Guid.NewGuid()}_{Path.GetFileName(imageFile.FileName)}";
                string uploadFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "images");

                // Kiểm tra và tạo thư mục nếu chưa có
                if (!Directory.Exists(uploadFolder))
                {
                    Directory.CreateDirectory(uploadFolder);
                }

                string filePath = Path.Combine(uploadFolder, uniqueFileName);

                // Lưu file vào thư mục
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    await imageFile.CopyToAsync(fileStream);
                }

                return $"/images/{uniqueFileName}"; // Trả về đường dẫn ảnh
            }

            // Nếu người dùng nhập URL ảnh thì sử dụng URL đó
            if (!string.IsNullOrEmpty(imageUrl))
            {
                return imageUrl;
            }

            // Nếu không có ảnh mới, giữ ảnh cũ
            return existingImageUrl;
        }
    }
}